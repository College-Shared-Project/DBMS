﻿select * from account;
select  * from  balanceaccount;
insert into account values(128,'ghg','hjmh','2004-05-02','male',2157,'hjug','gfhfhg','ghvh','hcgd','2006-05-01');
insert into balanceaccount values(55,25,75,87,65);
select * from account a join(select * from balanceaccount b) where a.Accountno=Accountno;