﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace vishalpurshabank
{
    public partial class withdrawuser : UserControl
    {
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");

        public withdrawuser()
        {
            InitializeComponent();
        }
        public void gridreferesh()
        {
            con.Open();
            String view_query = "select Accountno,save_balance,fixed_deposit from balanceaccount1";

            SqlDataAdapter v_sda = new SqlDataAdapter(view_query, con);
            v_sda.SelectCommand.ExecuteNonQuery();
            DataTable dt = new DataTable();
            v_sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
        private void withdrawuser_Load(object sender, EventArgs e)
        {
            gridreferesh();
        }

        public String accountno, savebalance, fixedbalance;

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "SAVING ACCOUNT")
            {

                {
                    con.Open();

                    String syntax = "select save_balance from balanceaccount1 where Accountno='" + textBox1.Text + "'";
                    SqlCommand cmd = new SqlCommand(syntax, con);
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    label3.Text = savebalance = dr[0].ToString();
                    con.Close();
                }

                {
                    try

                    {
                        con.Open();
                   
                        int sum;
                        sum = Convert.ToInt32(savebalance) - Convert.ToInt32(textBox2.Text);
                       String query1=" update balanceaccount1  set save_balance ='"+ sum+"' where Accountno = '"+textBox1.Text+"'";
                        SqlDataAdapter v_sda = new SqlDataAdapter(query1, con);
                        v_sda.SelectCommand.ExecuteNonQuery();
                       
                        MessageBox.Show("withdraw");
                        con.Close();
                        con.Open();
                        String query2 = "  exec news_trigger_afterinsert41 @Accountno='"+textBox1.Text+"',@bal='"+textBox2.Text+"'";
                        SqlDataAdapter v_sda2 = new SqlDataAdapter(query2, con);
                        v_sda2.SelectCommand.ExecuteNonQuery();
                        con.Close();
                        gridreferesh();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("invalid sql opration " + ex);
                    }
                    con.Close();
               
                }

            }
            else if (comboBox1.Text == "FIXED ACCOUNT")
            {


                {
                    con.Open();

                    String syntax = "select fixed_deposit from balanceaccount1 where Accountno='" + textBox1.Text + "'";
                    SqlCommand cmd = new SqlCommand(syntax, con);
                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();
                    label3.Text = fixedbalance = dr[0].ToString();
                    con.Close();
                }

                {
                
                    try

                    {
                        con.Open();
                        String query2 = " update balanceaccount1  set fixed_deposit =0 where Accountno = '" + textBox1.Text + "'";
                        SqlDataAdapter v_sda2 = new SqlDataAdapter(query2, con);
                        v_sda2.SelectCommand.ExecuteNonQuery();
                        con.Close();
                        gridreferesh();
                        MessageBox.Show("withdraw");
                        
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("invalid sql opration " + ex);
                    }

                    
                   
                }

            }
            else
            {
                MessageBox.Show("please enter the vailid data");
            }
        }
    }
    }
