﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace vishalpurshabank
{
    public partial class table : UserControl
    {
        public table()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void table_Load(object sender, EventArgs e)
        {
            Grid();
       
    }
        public void  Grid()
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");

            con.Open();
            this.Refresh();
            String view_query = "select a.Accountno,a.pincode,a.customername,a.Fathername,a.dateofbirth,a.sex,a.cellnumber,a.country,a.cityname,a.address,a.date,b.save_balance,b.fixed_deposit,b.duration from account1 a,balanceaccount1 b where a.Accountno=b.Accountno";

            SqlDataAdapter v_sda = new SqlDataAdapter(view_query, con);
            v_sda.SelectCommand.ExecuteNonQuery();
            DataTable dt = new DataTable();
            v_sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();

        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            Grid();
        }
    }
}
