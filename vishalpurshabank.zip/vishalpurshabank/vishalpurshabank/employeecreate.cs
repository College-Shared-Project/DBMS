﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace vishalpurshabank
{
    public partial class employeecreate : UserControl
    {
        public employeecreate()
        {
            InitializeComponent();
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void employeecreate_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "" || ctxt1.Text == "" || textBox8.Text == "" || textBox1.Text == "")
            {
                MessageBox.Show("please enter valid data");
            }
            else
            {
                SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");
                con.Open();
                String query = "insert into  employee1 (employeename,dateofbirth,sex,cellno,country,Cityname,address,email,date,password,fathername) values ('" + textBox2.Text + "','" + dateTimePicker2.Text + "','" + ctxt1.Text + "','" + textBox7.Text + "','" + textBox8.Text + "','" + textBox9.Text + "', '" + textBox10.Text + "', '" + textBox12.Text + "', '" + dateTimePicker1.Text + "','" + textBox1.Text + "','" + textBox3.Text + "')";
                SqlDataAdapter SDA = new SqlDataAdapter(query, con);
                SDA.SelectCommand.ExecuteNonQuery();

                MessageBox.Show("DATA INSRTED SUCESSFULLY!!!!");
                con.Close();
                con.Open();

                string str = " insert into login(username,password)values('" + textBox2.Text + "','" + textBox1.Text + "')";
                SqlDataAdapter SDA1 = new SqlDataAdapter(str, con);
                SDA1.SelectCommand.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("new employee created");
            }
        }

        private void lbl4_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
