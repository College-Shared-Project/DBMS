﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace vishalpurshabank
{
    public partial class deposituser : UserControl
    {



        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");
        public deposituser()
        {
            InitializeComponent();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        public String accountno, savebalance, fixedbalance;

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void gridreferesh()
        {
            con.Open();
            String view_query = "select Accountno,save_balance,fixed_deposit from balanceaccount1";

            SqlDataAdapter v_sda = new SqlDataAdapter(view_query, con);
            v_sda.SelectCommand.ExecuteNonQuery();
            DataTable dt = new DataTable();
            v_sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void deposituser_Load(object sender, EventArgs e)
        {

            gridreferesh();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")

            {
                MessageBox.Show("please enter the valid details ");
            }
            else
            {
                if (comboBox1.Text == "SAVING ACCOUNT")
                {

                    {
                        con.Open();

                        String syntax = "select save_balance from balanceaccount1 where Accountno='" + textBox1.Text + "'";
                        SqlCommand cmd = new SqlCommand(syntax, con);
                        SqlDataReader dr = cmd.ExecuteReader();
                        dr.Read();
                        label3.Text = savebalance = dr[0].ToString();
                        con.Close();
                    }

                    {
                        try
                        {

                            {
                                con.Open();
                                int sum;


                                sum = Convert.ToInt32(savebalance) + Convert.ToInt32(textBox2.Text);
                                String query1 = " update balanceaccount1  set save_balance ='" + sum + "' where Accountno = '" + textBox1.Text + "'";
                                SqlDataAdapter v_sda = new SqlDataAdapter(query1, con);
                                v_sda.SelectCommand.ExecuteNonQuery();

                                con.Close();
                                con.Open();
                                String query2 = "  exec news_trigger_afterinsert42 @Accountno='" + textBox1.Text + "',@bal='" + textBox2.Text + "'";
                                SqlDataAdapter v_sda2 = new SqlDataAdapter(query2, con);
                                v_sda2.SelectCommand.ExecuteNonQuery();
                                con.Close();
                                gridreferesh();

                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("invalid sql opration " + ex);
                        }

                        MessageBox.Show("deposited");

                    }

                }
                else if (comboBox1.Text == "FIXED ACCOUNT")
                {


                    {
                        con.Open();

                        String syntax = "select fixed_deposit from balanceaccount1 where Accountno='" + textBox1.Text + "'";
                        SqlCommand cmd = new SqlCommand(syntax, con);
                        SqlDataReader dr = cmd.ExecuteReader();
                        dr.Read();
                        label3.Text = fixedbalance = dr[0].ToString();
                        con.Close();
                    }

                    {

                        try

                        {
                            con.Open();

                            String query15 = " update balanceaccount1  set fixed_deposit='" + textBox2.Text + "' where Accountno = '" + textBox1.Text + "'";
                            SqlDataAdapter v_sda5 = new SqlDataAdapter(query15, con);
                            v_sda5.SelectCommand.ExecuteNonQuery();

                            con.Close();
                            gridreferesh();
                            MessageBox.Show("deposited");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("invalid sql opration " + ex);
                        }


                    }

                }
                else
                {
                    MessageBox.Show("please enter the valid details");
                }


            }
        }
    }
}
