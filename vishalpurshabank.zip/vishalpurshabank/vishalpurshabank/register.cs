﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vishalpurshabank
{
    public partial class register : Form
    {
        public register()
        {
            InitializeComponent();
           
        }

        private void register_Load(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
            accountregister ar = new accountregister();
            ar.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            registration ri = new registration();
            ri.Show();
            this.Hide();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            loan lo = new loan();
            lo.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            createaccountuser1.BringToFront();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            updateaccount1.BringToFront();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            deleteaccoun1user1.BringToFront();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            deposituser1.BringToFront();
        
        }

        private void button10_Click(object sender, EventArgs e)
        {
            withdrawuser1.BringToFront();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {

            loaning1.BringToFront();
        }

        private void table1_Load(object sender, EventArgs e)
        {
            
        }

        private void first1_Load(object sender, EventArgs e)
        {

        }

        private void first1_Load_1(object sender, EventArgs e)
        {

        }

        private void button3_Click_2(object sender, EventArgs e)
        {
            
            table1.BringToFront();
            this.Refresh();
        }

        private void seachbyaccount12_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            seachbyaccount11.BringToFront();
        }

        private void seachbyaccount11_Load(object sender, EventArgs e)
        {

        }

        private void createaccountuser1_Load(object sender, EventArgs e)
        {

        }
    }
}
