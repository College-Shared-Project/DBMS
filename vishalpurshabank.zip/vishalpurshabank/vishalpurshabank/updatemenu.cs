﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace vishalpurshabank
{
    public partial class updatemenu : UserControl
    {
        Image file1,file2,file3,file4;
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");


        public updatemenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            OpenFileDialog f = new OpenFileDialog();
            f.Filter = "JPG(*.JPG)|*.jpg";
            if (f.ShowDialog() == DialogResult.OK)
            {
                file1 = Image.FromFile(f.FileName);
                pictureBox1.Image = file1;


            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
        }

        private void button4_Click(object sender, EventArgs e)
        {

            OpenFileDialog f = new OpenFileDialog();
            f.Filter = "JPG(*.JPG)|*.jpg";
            if (f.ShowDialog() == DialogResult.OK)
            {
                file2 = Image.FromFile(f.FileName);
                pictureBox3.Image = file2;


            }
        }

        private void button8_Click(object sender, EventArgs e)
        { 
            string a = "deposit";
        SaveFileDialog f = new SaveFileDialog();
        f.Filter = "JPG(*.JPG)|*.jpg";
            if (f.ShowDialog() == DialogResult.OK)
            {
                file2.Save(f.FileName);
                con.Open();
                String str2 = "update image1 set path='" + f.FileName + "'where name='deposit'";
                SqlDataAdapter SDA2 = new SqlDataAdapter(str2, con);
                SDA2.SelectCommand.ExecuteNonQuery();

                con.Close();

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {



            OpenFileDialog f = new OpenFileDialog();
            f.Filter = "JPG(*.JPG)|*.jpg";
            if (f.ShowDialog() == DialogResult.OK)
            {
                file3 = Image.FromFile(f.FileName);
                pictureBox2.Image = file3;


            }
        }

        private void updatemenu_Load(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            OpenFileDialog f = new OpenFileDialog();
            f.Filter = "JPG(*.JPG)|*.jpg";
            if (f.ShowDialog() == DialogResult.OK)
            {
                file1 = Image.FromFile(f.FileName);
                pictureBox1.Image = file1;


            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string a = "loan";
            SaveFileDialog f = new SaveFileDialog();
            f.Filter = "JPG(*.JPG)|*.jpg";
            if (f.ShowDialog() == DialogResult.OK)
            {
                file1.Save(f.FileName);
                con.Open();
                String str1 = "update image1 set path='" + f.FileName + "'where name='loan'";
                SqlDataAdapter SDA1 = new SqlDataAdapter(str1, con);
                SDA1.SelectCommand.ExecuteNonQuery();

                con.Close();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string a = "withdraw";
            SaveFileDialog f = new SaveFileDialog();
            f.Filter = "JPG(*.JPG)|*.jpg";
            if (f.ShowDialog() == DialogResult.OK)
            {
                file3.Save(f.FileName);
                con.Open();
                String str3 = "update image1 set path='" + f.FileName + "'where name='withdraw'";
                SqlDataAdapter SDA3 = new SqlDataAdapter(str3, con);
                SDA3.SelectCommand.ExecuteNonQuery();

                con.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

           

        }

        private void button7_Click(object sender, EventArgs e)
        {
            
            
        }
    }
}
