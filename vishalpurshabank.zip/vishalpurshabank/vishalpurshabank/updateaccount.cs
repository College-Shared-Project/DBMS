﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace vishalpurshabank
{
    public partial class updateaccount : UserControl
    {
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");
        public updateaccount()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
           con.Open();
            String query = "UPDATE  account1 set pincode='"+ textBox6.Text + "',customername='" + textBox2.Text + "',Fathername='" + textBox3.Text + "',dateofbirth='" + dateofbirth.Text + "',sex='" + textBox4.Text + "',cellnumber='" + textBox7.Text + "',country= '" + textBox8.Text + "',cityname= '" + textBox9.Text + "',address= '" + textBox10.Text + "',email='" + textBox12.Text + "', date='" + date.Text + "' where Accountno='"+textBox1.Text+"'";
            SqlDataAdapter SDA = new SqlDataAdapter(query, con);
            SDA.SelectCommand.ExecuteNonQuery();
            MessageBox.Show("updated SUCESSFULLY!!!!");
            
            con.Close();
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void bt1_Click(object sender, EventArgs e)
        {

            con.Open();

            String str = "select * from account1 where Accountno='" + textBox1.Text + "'";
            SqlDataAdapter adpt = new SqlDataAdapter(str, con);
            DataSet login = new DataSet();
            adpt.Fill(login);
            foreach (DataRow dr in login.Tables[0].Rows)
            {
                textBox6.Text = login.Tables[0].Rows[0]["pincode"].ToString();
                textBox2.Text = login.Tables[0].Rows[0]["customername"].ToString();
           textBox3.Text = login.Tables[0].Rows[0]["Fathername"].ToString();
                dateofbirth.Text = login.Tables[0].Rows[0]["dateofbirth"].ToString();
                textBox4 .Text = login.Tables[0].Rows[0]["sex"].ToString();
                textBox7.Text = login.Tables[0].Rows[0]["cellnumber"].ToString();
                textBox8.Text = login.Tables[0].Rows[0]["country"].ToString();
                textBox9.Text = login.Tables[0].Rows[0]["cityname"].ToString();
                textBox10.Text = login.Tables[0].Rows[0]["address"].ToString();
                textBox12.Text = login.Tables[0].Rows[0]["email"].ToString();
                date.Text = login.Tables[0].Rows[0]["date"].ToString();
            }
            con.Close();
        }

        private void updateaccount_Load(object sender, EventArgs e)
        {

        }

        private void lbl8_Click(object sender, EventArgs e)
        {

        }
    }
}
