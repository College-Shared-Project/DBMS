﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace vishalpurshabank
{
    public partial class loandetail : Form
    {
        public loandetail()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");


            con.Open();
            String query = "insert into loan1 (Accountno,loan_amount,type,date,duration) values ('" + textBox1.Text + "','" + textBox14.Text + "','" + comboBox1.Text + "','" + dateTimePicker1.Text+"','" + textBox2.Text + "')";
                SqlDataAdapter SDA = new SqlDataAdapter(query, con);
            SDA.SelectCommand.ExecuteNonQuery();

            MessageBox.Show("DATA INSRTED SUCESSFULLY!!!!");
            con.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {



            this.Close();
         
        }

        private void textBox14_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
        }
    }
}
