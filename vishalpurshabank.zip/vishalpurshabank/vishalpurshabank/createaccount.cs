﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace vishalpurshabank
{
    public partial class createaccount : Form
    {
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");
        public createaccount()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void saving_account1_Load(object sender, EventArgs e)
        {

        }

        private void createaccount_Load(object sender, EventArgs e)
        {
            int i = 0;
            con.Open();

            string str1 = "select Accountno from account1 ";
            SqlDataAdapter adpt = new SqlDataAdapter(str1, con);
            DataSet login1 = new DataSet();
            adpt.Fill(login1);
            foreach (DataRow dr in login1.Tables[0].Rows)
            {
                textBox6.Text = login1.Tables[0].Rows[i]["Accountno"].ToString();
                i++;
            }
            con.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            

   
            //register cs = new register();
            //cs.Show();
            


        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            registration reg = new registration();
            this.Hide();
            reg.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            con.Open();
            String query = "insert into balanceaccount1(Accountno,save_balance,intrest_rate,fixed_deposit,fixed_intrest,duration)values('" + textBox6.Text + "','" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "')";
            SqlDataAdapter SDA = new SqlDataAdapter(query, con);
            SDA.SelectCommand.ExecuteNonQuery();

            MessageBox.Show("DATA INSRTED SUCESSFULLY!!!!");

            con.Close();
            this.Hide();
        }
    }
}
