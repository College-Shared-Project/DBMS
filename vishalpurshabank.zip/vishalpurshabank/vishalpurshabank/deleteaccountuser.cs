﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace vishalpurshabank
{
    public partial class deleteaccountuser : UserControl
    {
        public deleteaccountuser()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");
            String str;
            con.Open();
            
            str = "delete from  account where Accountno='" + textBox15.Text + "'";
            SqlDataAdapter adpt = new SqlDataAdapter(str, con);
            DataSet login = new DataSet();
            adpt.Fill(login);
            MessageBox.Show("'" + textBox15.Text + "' deleted sucessfully ");
        }
    }
}
