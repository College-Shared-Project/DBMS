﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace vishalpurshabank
{
    public partial class firstuc : UserControl
    {
        public firstuc()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            using (SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True"))
            {
                SqlCommand cmd = new SqlCommand("select * from login where username like @username and password=@password;");
                cmd.Parameters.AddWithValue("@username", textBox1.Text);
                cmd.Parameters.AddWithValue("@password", textBox2.Text);
                cmd.Connection = con;
                con.Open();
                DataSet ds = new DataSet();


                SqlDataAdapter v_sda = new SqlDataAdapter(cmd);

                v_sda.Fill(ds);

                bool loginsucessfull = ((ds.Tables.Count > 0) && (ds.Tables[0].Rows.Count > 0));

                if (comboBox1.Text == "ADMIN")
                {
                   if(textBox1.Text=="manager"&&textBox2.Text=="456")
                    {
                        MessageBox.Show("Welcome Manager");
                        adminlogin a = new adminlogin();
                        
                        a.Show();
                     

                    }
                    else
                    {
                        MessageBox.Show("please check username and password");
                    }
                   }
                
                else if (comboBox1.Text == "EMPLOYEE")
                {

                    if (loginsucessfull)
                    {
                        MessageBox.Show("success");
                        register reg = new register();


                        reg.Show();
                      

                    }
                    else
                    {
                        MessageBox.Show("invalid");
                    }
                }
                else
                {
                    MessageBox.Show("Please select the type of user");
                }
                con.Close();
            }


        }

        private void firstuc_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                if (textBox1.Text.Trim() == String.Empty)
                {
                    MessageBox.Show("please enter username");
                    textBox1.Focus();
                }
                textBox2.Focus();
                e.Handled = true;
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (textBox2.Text.Trim() == String.Empty)
                {
                    MessageBox.Show("please enter password");
                    textBox2.Focus();
                }
                comboBox1.Focus();
                e.Handled = true;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.Focus();
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }

        private void textBox1_TextAlignChanged(object sender, EventArgs e)
        {
         
            if (textBox1.Text==null)
            {
                MessageBox.Show("please enter username");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
