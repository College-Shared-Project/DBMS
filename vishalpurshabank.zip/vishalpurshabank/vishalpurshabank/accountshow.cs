﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Xml.Linq;
    

namespace vishalpurshabank
{
    public partial class accountshow : Form
    {
        seachbyaccount1 sba = new seachbyaccount1();
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");
        String str;
        SqlCommand comm;
        public accountshow()
        {
            InitializeComponent();
        }

        private void accountshow_Load(object sender, EventArgs e)
        {
            con.Open();
           
             str = "select Accountno,pincode from account where Accountno='130'";
            SqlDataAdapter adpt = new SqlDataAdapter(str, con);
            DataSet login = new DataSet();
            adpt.Fill(login);
            foreach(DataRow dr in login.Tables[0].Rows )
            {
                label1.Text += login.Tables[0].Rows[0]["Accountno"].ToString();
                label2.Text += login.Tables[0].Rows[0]["pincode"].ToString();

            }
            con.Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click_1(object sender, EventArgs e)
        {

        }
    }
}
