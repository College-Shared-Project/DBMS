﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace vishalpurshabank
{
    public partial class DeleteEmployee : UserControl
    {
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");
        
        public DeleteEmployee()
        {
            InitializeComponent();
        }

        private void DeleteEmployee_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            con.Open();
            String query = "delete from employee1 where employeeID='" + textBox15.Text + "'";
            SqlDataAdapter adpt = new SqlDataAdapter(query, con);
            adpt.SelectCommand.ExecuteNonQuery();
            DataSet login = new DataSet();
            adpt.Fill(login);
            MessageBox.Show("deleted successfully");
            con.Close();
        }
    }
}
