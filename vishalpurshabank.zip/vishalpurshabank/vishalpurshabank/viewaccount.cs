﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vishalpurshabank
{
    public partial class viewaccount : Form
    {
        registration r = new registration();
        public viewaccount()
        {
            InitializeComponent();
        }

        private void viewaccount_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            accountregister ar = new accountregister();
            ar.Show();
            this.Hide();
        }
    }
}
