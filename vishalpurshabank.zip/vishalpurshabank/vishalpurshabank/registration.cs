﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Design;
using System.Data.Sql;
using System.IO;
namespace vishalpurshabank
{
    public partial class registration : Form
    {
        public static String mes;
        
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");
        public registration()
        {
            InitializeComponent();
        }
          private void button2_Click(object sender, EventArgs e)
        {
            register r = new register();
            r.Show();
            this.Hide();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            register r = new register();
            r.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {


            textBox2.Clear();
            textBox3.Clear();

            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();

            textBox12.Clear();


        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
                   con.Open();
            String query = "insert into account1 (pincode,customername,Fathername,dateofbirth,sex,cellnumber,country,cityname,address,email,empid,date) values ('"+textBox6.Text+"','"+textBox2.Text+"','"+textBox3.Text+"','"+dateofbirth.Text+"','"+ctxt1.Text+"','"+textBox7.Text+"', '"+textBox8.Text+"', '"+ textBox9.Text+"', '"+textBox10.Text+"','"+textBox12.Text+"','"+textBox1.Text+"', '"+date.Text+"')";
            SqlDataAdapter SDA = new SqlDataAdapter(query, con);
            SDA.SelectCommand.ExecuteNonQuery();
            mes = "new account '"+textBox2.Text+"' has been created";
            
            MessageBox.Show("DATA INSRTED SUCESSFULLY!!!!");
            createaccount ca = new createaccount();
            this.Hide();
            ca.Show();
            con.Close();

        }
        
        private void panel2_Paint(object sender, PaintEventArgs e)
        {
        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lbl17_Click(object sender, EventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl7_Click(object sender, EventArgs e)
        {

        }

        private void ctxt1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lbl3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl4_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl5_Click(object sender, EventArgs e)
        {

        }

        private void lbl6_Click(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lbl10_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl11_Click(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl12_Click(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl8_Click(object sender, EventArgs e)
        {

        }

        private void lbl14_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
   