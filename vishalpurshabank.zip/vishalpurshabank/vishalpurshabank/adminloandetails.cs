﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace vishalpurshabank
{
    public partial class adminloandetails : UserControl
    {
        public adminloandetails()
        {
            InitializeComponent();
        }

        private void adminloandetails_Load(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");

            con.Open();
            String view_query = "select a.Accountno,b.customername,a.loan_amount,a.type,a.date,a.duration from loan1 a,account1 b where a.Accountno=b.Accountno";

            SqlDataAdapter v_sda = new SqlDataAdapter(view_query, con);
            v_sda.SelectCommand.ExecuteNonQuery();
            DataTable dt = new DataTable();
            v_sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();

        }
    }
}
