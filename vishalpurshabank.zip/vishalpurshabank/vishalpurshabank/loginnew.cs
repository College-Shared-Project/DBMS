﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Design;
using System.Runtime.InteropServices;

namespace vishalpurshabank
{
    public partial class loginnew : Form
    {

        public const int WM_NCLUBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd,
            int Msg, int wParam, int IParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        public loginnew()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {

            using (SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True"))
            {
                SqlCommand cmd = new SqlCommand("select * from login where username like @username and password=@password;");
                cmd.Parameters.AddWithValue("@username", textBox1.Text);
                cmd.Parameters.AddWithValue("@password", textBox2.Text);
                cmd.Connection = con;
                con.Open();
                DataSet ds = new DataSet();


                SqlDataAdapter v_sda = new SqlDataAdapter(cmd);

                v_sda.Fill(ds);
                
                bool loginsucessfull = ((ds.Tables.Count > 0) && (ds.Tables[0].Rows.Count > 0));
                
                    if (comboBox1.Text == "ADMIN")
                    {
                        if (loginsucessfull)
                        {
                            MessageBox.Show("sucess");
                            adminlogin
                            reg = new adminlogin();


                            reg.Show();
                            this.Hide();

                        }
                        else
                        {
                            MessageBox.Show("invalid");
                        }

                        con.Close();

                    }
               else if (comboBox1.Text == "EMPLOYEE")
                {

                    if (loginsucessfull)
                    {
                        MessageBox.Show("sucess");
                        register reg = new register();


                        reg.Show();
                        this.Hide();

                    }
                    else
                    {
                        MessageBox.Show("invalid");
                    }
                }
                    else
                {
                    MessageBox.Show("Please select the type of user");
                }
                con.Close();
            }
           
        }
private void button1_Click(object sender, EventArgs e)
        {
            newvishalmain m = new newvishalmain();
            this.Hide();
            m.Show();

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void loginnew_Load(object sender, EventArgs e)
        {

        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLUBUTTONDOWN, HT_CAPTION,
                    0);
            }
        }
    }
}