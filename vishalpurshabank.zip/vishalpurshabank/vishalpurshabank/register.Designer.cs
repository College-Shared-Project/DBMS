﻿namespace vishalpurshabank
{
    partial class register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(register));
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.loaning1 = new vishalpurshabank.loaning();
            this.deleteaccoun1user1 = new vishalpurshabank.deleteaccoun1user();
            this.deposituser1 = new vishalpurshabank.deposituser();
            this.seachbyaccount11 = new vishalpurshabank.seachbyaccount1();
            this.table1 = new vishalpurshabank.table();
            this.withdrawuser1 = new vishalpurshabank.withdrawuser();
            this.createaccountuser1 = new vishalpurshabank.createaccountuser();
            this.updateaccount1 = new vishalpurshabank.updateaccount();
            this.seachbyaccount12 = new vishalpurshabank.seachbyaccount1();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(116)))), ((int)(((byte)(216)))));
            this.panel2.Location = new System.Drawing.Point(-58, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(987, 35);
            this.panel2.TabIndex = 3;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(6, 40);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(923, 44);
            this.panel1.TabIndex = 8;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(118)))), ((int)(((byte)(211)))));
            this.label1.Location = new System.Drawing.Point(391, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "Menu page";
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.Location = new System.Drawing.Point(796, 9);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(34, 35);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Monotype Corsiva", 26.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(118)))), ((int)(((byte)(211)))));
            this.label2.Location = new System.Drawing.Point(103, -1);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(282, 43);
            this.label2.TabIndex = 1;
            this.label2.Text = "PV BAK LIMITED";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(47, 52);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(116)))), ((int)(((byte)(216)))));
            this.panel5.Controls.Add(this.button4);
            this.panel5.Controls.Add(this.button3);
            this.panel5.Controls.Add(this.button2);
            this.panel5.Controls.Add(this.button8);
            this.panel5.Controls.Add(this.button10);
            this.panel5.Controls.Add(this.button6);
            this.panel5.Controls.Add(this.button9);
            this.panel5.Controls.Add(this.button7);
            this.panel5.Location = new System.Drawing.Point(-1, 114);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(203, 428);
            this.panel5.TabIndex = 4;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(170)))), ((int)(((byte)(245)))));
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Century", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(0, 160);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(203, 47);
            this.button4.TabIndex = 9;
            this.button4.Text = "Search Account by No";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(170)))), ((int)(((byte)(245)))));
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(3, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(203, 45);
            this.button3.TabIndex = 7;
            this.button3.Text = "view accounts";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_2);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(170)))), ((int)(((byte)(245)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(0, 391);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(203, 44);
            this.button2.TabIndex = 8;
            this.button2.Text = "Loan";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(170)))), ((int)(((byte)(245)))));
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(-3, 219);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(206, 47);
            this.button8.TabIndex = 4;
            this.button8.Text = "Delete An Account";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(170)))), ((int)(((byte)(245)))));
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(3, 338);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(200, 47);
            this.button10.TabIndex = 7;
            this.button10.Text = "Withdrawl\r\n";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(170)))), ((int)(((byte)(245)))));
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Century", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(3, 54);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(200, 47);
            this.button6.TabIndex = 3;
            this.button6.Text = "Create An Account";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(170)))), ((int)(((byte)(245)))));
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(0, 275);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(203, 47);
            this.button9.TabIndex = 6;
            this.button9.Text = "Deposit\r\n\r\n";
            this.button9.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(170)))), ((int)(((byte)(245)))));
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Century", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(0, 107);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(206, 47);
            this.button7.TabIndex = 5;
            this.button7.Text = "Update account details";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(116)))), ((int)(((byte)(216)))));
            this.panel3.Location = new System.Drawing.Point(3, 87);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(923, 10);
            this.panel3.TabIndex = 9;
            // 
            // loaning1
            // 
            this.loaning1.Location = new System.Drawing.Point(198, 105);
            this.loaning1.Name = "loaning1";
            this.loaning1.Size = new System.Drawing.Size(734, 418);
            this.loaning1.TabIndex = 14;
            // 
            // deleteaccoun1user1
            // 
            this.deleteaccoun1user1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.deleteaccoun1user1.Location = new System.Drawing.Point(198, 103);
            this.deleteaccoun1user1.Name = "deleteaccoun1user1";
            this.deleteaccoun1user1.Size = new System.Drawing.Size(729, 424);
            this.deleteaccoun1user1.TabIndex = 13;
            // 
            // deposituser1
            // 
            this.deposituser1.Location = new System.Drawing.Point(201, 103);
            this.deposituser1.Name = "deposituser1";
            this.deposituser1.Size = new System.Drawing.Size(728, 428);
            this.deposituser1.TabIndex = 12;
            // 
            // seachbyaccount11
            // 
            this.seachbyaccount11.Location = new System.Drawing.Point(198, 96);
            this.seachbyaccount11.Name = "seachbyaccount11";
            this.seachbyaccount11.Size = new System.Drawing.Size(731, 446);
            this.seachbyaccount11.TabIndex = 11;
            this.seachbyaccount11.Load += new System.EventHandler(this.seachbyaccount11_Load);
            // 
            // table1
            // 
            this.table1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("table1.BackgroundImage")));
            this.table1.Location = new System.Drawing.Point(198, 97);
            this.table1.Name = "table1";
            this.table1.Size = new System.Drawing.Size(746, 442);
            this.table1.TabIndex = 10;
            // 
            // withdrawuser1
            // 
            this.withdrawuser1.Location = new System.Drawing.Point(198, 105);
            this.withdrawuser1.Name = "withdrawuser1";
            this.withdrawuser1.Size = new System.Drawing.Size(729, 432);
            this.withdrawuser1.TabIndex = 15;
            // 
            // createaccountuser1
            // 
            this.createaccountuser1.BackColor = System.Drawing.Color.White;
            this.createaccountuser1.Location = new System.Drawing.Point(201, 91);
            this.createaccountuser1.Name = "createaccountuser1";
            this.createaccountuser1.Size = new System.Drawing.Size(726, 440);
            this.createaccountuser1.TabIndex = 16;
            this.createaccountuser1.Load += new System.EventHandler(this.createaccountuser1_Load);
            // 
            // updateaccount1
            // 
            this.updateaccount1.Location = new System.Drawing.Point(201, 90);
            this.updateaccount1.Name = "updateaccount1";
            this.updateaccount1.Size = new System.Drawing.Size(688, 485);
            this.updateaccount1.TabIndex = 17;
            // 
            // seachbyaccount12
            // 
            this.seachbyaccount12.Location = new System.Drawing.Point(201, 87);
            this.seachbyaccount12.Name = "seachbyaccount12";
            this.seachbyaccount12.Size = new System.Drawing.Size(725, 455);
            this.seachbyaccount12.TabIndex = 10;
            // 
            // register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(929, 544);
            this.Controls.Add(this.seachbyaccount12);
            this.Controls.Add(this.updateaccount1);
            this.Controls.Add(this.createaccountuser1);
            this.Controls.Add(this.withdrawuser1);
            this.Controls.Add(this.loaning1);
            this.Controls.Add(this.deleteaccoun1user1);
            this.Controls.Add(this.deposituser1);
            this.Controls.Add(this.seachbyaccount11);
            this.Controls.Add(this.table1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "register";
            this.Text = "register";
            this.Load += new System.EventHandler(this.register_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel3;
        private table table1;
        private seachbyaccount1 seachbyaccount11;
        private deposituser deposituser1;
        private deleteaccoun1user deleteaccoun1user1;
        private loaning loaning1;
        private withdrawuser withdrawuser1;
        private createaccountuser createaccountuser1;
        private updateaccount updateaccount1;
        private seachbyaccount1 seachbyaccount12;
    }
}