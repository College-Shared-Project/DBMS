﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace vishalpurshabank
{
    public partial class depositmenu : UserControl
    {
        string label;
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");

        public depositmenu()
        {
            InitializeComponent();
        }

        private void depositmenu_Load(object sender, EventArgs e)
        {
            con.Open();
    
            String str = "select path from image1 where name='deposit' ";
            SqlCommand cmd1 = new SqlCommand(str, con);
            SqlDataReader dr = cmd1.ExecuteReader();
            dr.Read();
            label = dr[0].ToString();
            con.Close();
            pictureBox1.ImageLocation = string.Format(label);

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
