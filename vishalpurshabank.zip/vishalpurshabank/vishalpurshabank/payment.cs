﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace vishalpurshabank
{
    public partial class payment : Form
    {
        public payment()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");
            con.Open();
            String query = "insert into payment (Accountno,pay_date,pay_amount) values('" + textBox1.Text + "','" + dateTimePicker1.Text + "','" + textBox3.Text + "')";
            SqlDataAdapter SDA = new SqlDataAdapter(query, con);
            SDA.SelectCommand.ExecuteNonQuery();
            String a;
            int sum;
            con.Close();

            con.Open();
            String syntax = "select loan_amount from loan1 where Accountno='" + textBox1.Text + "'";
            SqlCommand cmd = new SqlCommand(syntax, con);
            SqlDataReader dr = cmd.ExecuteReader();
            dr.Read();
            a = dr[0].ToString();

            con.Close();

            sum = Convert.ToInt32(a) - Convert.ToInt32(textBox3.Text);
            if (sum <= 0)
            {
                con.Open();
                string query2 = "delete from loan1 where Accountno='" + textBox1.Text + "'";
                SqlDataAdapter SDA2 = new SqlDataAdapter(query2, con);
                SDA2.SelectCommand.ExecuteNonQuery();
                MessageBox.Show("LOAN  COMPLETLY PAYED!!!!");
                con.Close();
               
            }
            else
            {
                con.Open();
                string query1 = "update loan1 set loan_amount='" + sum + "' where Accountno='" + textBox1.Text + "'";
                SqlDataAdapter SDA1 = new SqlDataAdapter(query1, con);
                SDA1.SelectCommand.ExecuteNonQuery();
                MessageBox.Show("DATA INSRTED SUCESSFULLY!!!!");
                con.Close();
             

            }


        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void payment_Load(object sender, EventArgs e)
        {

        }
    }
}
