﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace vishalpurshabank
{
    public partial class viewtransaction1 : Form
    {
        public viewtransaction1()
        {
            InitializeComponent();
        }

        private void viewtransaction1_Load(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {

            label1.Text = null;

            label3.Text = null;
            label5.Text = null;
            label6.Text = null;



            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");
            String str;
            int i = 0;
            con.Open();
            {
                str = "select Accountno,pincode,customername,dateofbirth,cellnumber from account where date='" + dateTimePicker1.Text + "'";
                SqlDataAdapter adpt = new SqlDataAdapter(str, con);
                DataSet login = new DataSet();
                adpt.Fill(login);

                foreach (DataRow dr in login.Tables[i].Rows)
                {
                    label1.Text += "new account having account no  ";

                    label1.Text += login.Tables[0].Rows[i]["Accountno"].ToString();
                    label1.Text += "" + Environment.NewLine + "";

                    label3.Text+="customer name  ";
                    label3.Text += login.Tables[0].Rows[i]["customername"].ToString();
                    label3.Text += "" + Environment.NewLine + " ";


                    label5.Text += "date of birth  ";
                    label5.Text += login.Tables[0].Rows[i]["dateofbirth"].ToString();
                    label5.Text += "" + Environment.NewLine + "";

                    label6.Text += "cell number  ";
                     label6.Text += login.Tables[0].Rows[i]["cellnumber"].ToString();
                    label6.Text += "       has been created" + Environment.NewLine + "  ";



                    i++;
                }
            }
            con.Close();
            i = 0;
            con.Open();
            {
                String str_1 = "select Accountno,type,date,duration,loan_amount from loan  where date='" + dateTimePicker1.Text + "' ";
                SqlDataAdapter adpt_1 = new SqlDataAdapter(str_1, con);
                DataSet login_1 = new DataSet();
                adpt_1.Fill(login_1);
                foreach (DataRow dr_1 in login_1.Tables[i].Rows)
                {
                    label1.Text += "new loan taken by account no ";
                    label1.Text += login_1.Tables[0].Rows[i]["Accountno"].ToString();
                    label1.Text += "" + Environment.NewLine + "";

                    label3.Text += "amount  ";
                  label3.Text += login_1.Tables[0].Rows[i]["loan_amount"].ToString();
                    label3.Text += "" + Environment.NewLine + "";


                    label5.Text += "loan type  ";
                    label5.Text += login_1.Tables[0].Rows[i]["type"].ToString();
                    label5.Text += "" + Environment.NewLine + "";

                    label6.Text += "for dutation";
                    label6.Text += login_1.Tables[0].Rows[i]["duration"].ToString();
                    label6.Text += "    years" + Environment.NewLine + "";

                    i++;
                }
              
            }
            con.Close();
        }
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
