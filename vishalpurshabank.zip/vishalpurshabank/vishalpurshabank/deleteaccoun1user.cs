﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace vishalpurshabank
{
    public partial class deleteaccoun1user : UserControl
    {
        public deleteaccoun1user()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");
            String str;
            con.Open();

            str = "delete from  account1 where Accountno='" + textBox15.Text + "'";
  SqlDataAdapter adpt = new SqlDataAdapter(str, con);
            adpt.SelectCommand.ExecuteNonQuery();
            DataSet login = new DataSet();
            adpt.Fill(login);
            con.Close();
            con.Open();

             String str1 = "delete from  balanceaccount1 where Accountno='" + textBox15.Text + "'";
            SqlDataAdapter adpt1 = new SqlDataAdapter(str1, con);
            adpt.SelectCommand.ExecuteNonQuery();
            DataSet login1 = new DataSet();
            adpt.Fill(login1);
            con.Close();

            con.Open();

          String  str2 = "delete from  account1 where Accountno='" + textBox15.Text + "'";
            SqlDataAdapter adpt2 = new SqlDataAdapter(str2, con);
            adpt.SelectCommand.ExecuteNonQuery();
            DataSet login2 = new DataSet();
            adpt.Fill(login2);
            con.Close();
            MessageBox.Show("'" + textBox15.Text + "' deleted sucessfully ");

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void lebl1_Click(object sender, EventArgs e)
        {

        }
    }
}
