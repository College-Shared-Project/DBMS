﻿namespace vishalpurshabank
{
    partial class adminlogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(adminlogin));
            this.panel5 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.b1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.deleteEmployee1 = new vishalpurshabank.DeleteEmployee();
            this.employeecreate1 = new vishalpurshabank.employeecreate();
            this.updatemenu1 = new vishalpurshabank.updatemenu();
            this.addintrests1 = new vishalpurshabank.Addintrests();
            this.deleteaccoun1user2 = new vishalpurshabank.deleteaccoun1user();
            this.seachbyaccount11 = new vishalpurshabank.seachbyaccount1();
            this.viewtransactionadmin1 = new vishalpurshabank.viewtransactionadmin();
            this.adminloandetails1 = new vishalpurshabank.adminloandetails();
            this.deleteaccoun1user1 = new vishalpurshabank.deleteaccoun1user();
            this.viewemployeinfo1 = new vishalpurshabank.viewemployeinfo();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(116)))), ((int)(((byte)(216)))));
            this.panel5.Controls.Add(this.button3);
            this.panel5.Controls.Add(this.b1);
            this.panel5.Controls.Add(this.button2);
            this.panel5.Controls.Add(this.button8);
            this.panel5.Controls.Add(this.button10);
            this.panel5.Controls.Add(this.button6);
            this.panel5.Controls.Add(this.button9);
            this.panel5.Controls.Add(this.button7);
            this.panel5.Location = new System.Drawing.Point(4, 68);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(200, 454);
            this.panel5.TabIndex = 4;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(170)))), ((int)(((byte)(245)))));
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(-6, 336);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(206, 47);
            this.button3.TabIndex = 10;
            this.button3.Text = "Add Intrest";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // b1
            // 
            this.b1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(170)))), ((int)(((byte)(245)))));
            this.b1.FlatAppearance.BorderSize = 0;
            this.b1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b1.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b1.ForeColor = System.Drawing.Color.White;
            this.b1.Location = new System.Drawing.Point(-9, 283);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(206, 47);
            this.b1.TabIndex = 9;
            this.b1.Text = "View Log";
            this.b1.UseVisualStyleBackColor = false;
            this.b1.Click += new System.EventHandler(this.b1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(170)))), ((int)(((byte)(245)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(-3, 217);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(203, 48);
            this.button2.TabIndex = 8;
            this.button2.Text = " View Loan Details";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(170)))), ((int)(((byte)(245)))));
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(0, 164);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(200, 47);
            this.button8.TabIndex = 4;
            this.button8.Text = "Delete Employee";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(170)))), ((int)(((byte)(245)))));
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(0, 389);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(200, 47);
            this.button10.TabIndex = 7;
            this.button10.Text = "Update menu";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(170)))), ((int)(((byte)(245)))));
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Century", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(-3, 5);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(200, 47);
            this.button6.TabIndex = 3;
            this.button6.Text = "Create New Employee";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(170)))), ((int)(((byte)(245)))));
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(-3, 58);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(203, 47);
            this.button9.TabIndex = 6;
            this.button9.Text = "View Employee Info";
            this.button9.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(170)))), ((int)(((byte)(245)))));
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Century", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(0, 111);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(197, 47);
            this.button7.TabIndex = 5;
            this.button7.Text = "Search Account by No";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(116)))), ((int)(((byte)(216)))));
            this.panel2.Location = new System.Drawing.Point(4, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(960, 13);
            this.panel2.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.Location = new System.Drawing.Point(810, 9);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(34, 59);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(12, 14);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(952, 44);
            this.panel1.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Monotype Corsiva", 26.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(118)))), ((int)(((byte)(211)))));
            this.label3.Location = new System.Drawing.Point(103, -1);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(282, 43);
            this.label3.TabIndex = 1;
            this.label3.Text = "PV BAK LIMITED";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(118)))), ((int)(((byte)(211)))));
            this.label2.Location = new System.Drawing.Point(449, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Menu page";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(47, 52);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(116)))), ((int)(((byte)(216)))));
            this.panel3.Location = new System.Drawing.Point(1, 54);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(960, 13);
            this.panel3.TabIndex = 10;
            // 
            // folderBrowserDialog1
            // 
            this.folderBrowserDialog1.HelpRequest += new System.EventHandler(this.folderBrowserDialog1_HelpRequest);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "new.jpg");
            // 
            // deleteEmployee1
            // 
            this.deleteEmployee1.Location = new System.Drawing.Point(206, 68);
            this.deleteEmployee1.Name = "deleteEmployee1";
            this.deleteEmployee1.Size = new System.Drawing.Size(841, 476);
            this.deleteEmployee1.TabIndex = 17;
            // 
            // employeecreate1
            // 
            this.employeecreate1.Location = new System.Drawing.Point(203, 62);
            this.employeecreate1.Name = "employeecreate1";
            this.employeecreate1.Size = new System.Drawing.Size(841, 476);
            this.employeecreate1.TabIndex = 16;
            this.employeecreate1.Load += new System.EventHandler(this.employeecreate1_Load);
            // 
            // updatemenu1
            // 
            this.updatemenu1.BackColor = System.Drawing.Color.White;
            this.updatemenu1.Location = new System.Drawing.Point(206, 64);
            this.updatemenu1.Name = "updatemenu1";
            this.updatemenu1.Size = new System.Drawing.Size(669, 458);
            this.updatemenu1.TabIndex = 15;
            // 
            // addintrests1
            // 
            this.addintrests1.BackColor = System.Drawing.Color.White;
            this.addintrests1.Location = new System.Drawing.Point(206, 67);
            this.addintrests1.Name = "addintrests1";
            this.addintrests1.Size = new System.Drawing.Size(764, 458);
            this.addintrests1.TabIndex = 14;
            // 
            // deleteaccoun1user2
            // 
            this.deleteaccoun1user2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.deleteaccoun1user2.Location = new System.Drawing.Point(204, 64);
            this.deleteaccoun1user2.Name = "deleteaccoun1user2";
            this.deleteaccoun1user2.Size = new System.Drawing.Size(764, 458);
            this.deleteaccoun1user2.TabIndex = 13;
            // 
            // seachbyaccount11
            // 
            this.seachbyaccount11.Location = new System.Drawing.Point(203, 64);
            this.seachbyaccount11.Name = "seachbyaccount11";
            this.seachbyaccount11.Size = new System.Drawing.Size(765, 455);
            this.seachbyaccount11.TabIndex = 10;
            // 
            // viewtransactionadmin1
            // 
            this.viewtransactionadmin1.Location = new System.Drawing.Point(204, 68);
            this.viewtransactionadmin1.Name = "viewtransactionadmin1";
            this.viewtransactionadmin1.Size = new System.Drawing.Size(765, 476);
            this.viewtransactionadmin1.TabIndex = 12;
            this.viewtransactionadmin1.Load += new System.EventHandler(this.viewtransactionadmin1_Load);
            // 
            // adminloandetails1
            // 
            this.adminloandetails1.Location = new System.Drawing.Point(203, 68);
            this.adminloandetails1.Name = "adminloandetails1";
            this.adminloandetails1.Size = new System.Drawing.Size(765, 476);
            this.adminloandetails1.TabIndex = 10;
            this.adminloandetails1.Load += new System.EventHandler(this.adminloandetails1_Load);
            // 
            // deleteaccoun1user1
            // 
            this.deleteaccoun1user1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.deleteaccoun1user1.Location = new System.Drawing.Point(203, 68);
            this.deleteaccoun1user1.Name = "deleteaccoun1user1";
            this.deleteaccoun1user1.Size = new System.Drawing.Size(760, 441);
            this.deleteaccoun1user1.TabIndex = 10;
            // 
            // viewemployeinfo1
            // 
            this.viewemployeinfo1.Location = new System.Drawing.Point(203, 67);
            this.viewemployeinfo1.Name = "viewemployeinfo1";
            this.viewemployeinfo1.Size = new System.Drawing.Size(760, 471);
            this.viewemployeinfo1.TabIndex = 11;
            // 
            // adminlogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1030, 519);
            this.ControlBox = false;
            this.Controls.Add(this.deleteEmployee1);
            this.Controls.Add(this.employeecreate1);
            this.Controls.Add(this.updatemenu1);
            this.Controls.Add(this.addintrests1);
            this.Controls.Add(this.deleteaccoun1user2);
            this.Controls.Add(this.seachbyaccount11);
            this.Controls.Add(this.viewtransactionadmin1);
            this.Controls.Add(this.adminloandetails1);
            this.Controls.Add(this.deleteaccoun1user1);
            this.Controls.Add(this.viewemployeinfo1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel5);
            this.Name = "adminlogin";
            this.Load += new System.EventHandler(this.adminlogin_Load);
            this.panel5.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private viewemployeinfo viewemployeinfo1;
        private deleteaccoun1user deleteaccoun1user1;
        private adminloandetails adminloandetails1;
        private viewtransactionadmin viewtransactionadmin1;
        private seachbyaccount1 seachbyaccount11;
        private System.Windows.Forms.Button button8;
        private deleteaccoun1user deleteaccoun1user2;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button button3;
        private Addintrests addintrests1;
        private updatemenu updatemenu1;
        private employeecreate employeecreate1;
        private DeleteEmployee deleteEmployee1;
    }
}