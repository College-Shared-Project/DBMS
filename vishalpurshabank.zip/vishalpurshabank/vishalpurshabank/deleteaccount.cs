﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace vishalpurshabank
{
    public partial class deleteaccount : Form
    {
        public deleteaccount()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {

            register r = new register();
            r.Show();
            this.Hide();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");
            String str;
            con.Open();

            str = "delete from  account where Accountno='" + textBox15.Text + "'";
            SqlDataAdapter adpt = new SqlDataAdapter(str, con);
            DataSet login = new DataSet();
            adpt.Fill(login);
            MessageBox.Show("'" + textBox15.Text + "' deleted sucessfully ");
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void lebl1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
