﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace vishalpurshabank
{
    public partial class newvishalmain : Form
    {
        public const int WM_NCLUBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd,
            int Msg, int wParam, int IParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        public newvishalmain()
        {

            InitializeComponent();
            firstuc1.BringToFront();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            firstuc1.BringToFront();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            seconduc1.BringToFront();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void seconduc1_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void newvishalmain_Load(object sender, EventArgs e)
        {

        }

        private void newvishalmain_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLUBUTTONDOWN, HT_CAPTION,
                    0);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            depositmenu1.BringToFront();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            withdramenu2.BringToFront();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            
        }

        private void featuremunu1_Load(object sender, EventArgs e)
        {

        }

        private void depositmenu1_Load(object sender, EventArgs e)
        {

        }
    }
}
