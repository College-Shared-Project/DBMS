﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Design;
using System.Data.Sql;

namespace vishalpurshabank
{
    public partial class createnewemployee : Form
    {
        public createnewemployee()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            adminlogin adl = new adminlogin();
            this.Hide();
            adl.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");
            con.Open();
            String query = "insert into  employee1 (employeename,dateofbirth,sex,cellno,country,Cityname,address,email,date,password,fathername) values ('" + textBox2.Text + "','" + dateTimePicker2.Text + "','" + ctxt1.Text + "','" + textBox7.Text + "','" + textBox8.Text + "','" + textBox9.Text + "', '" + textBox10.Text + "', '" + textBox12.Text + "', '" + dateTimePicker1.Text + "','"+textBox1.Text+"','" + textBox3.Text + "')";
            SqlDataAdapter SDA = new SqlDataAdapter(query, con);
            SDA.SelectCommand.ExecuteNonQuery();

            MessageBox.Show("DATA INSRTED SUCESSFULLY!!!!");
            con.Close();
            con.Open();
          
           string str=" insert into login(username,password)values('"+textBox2.Text+"','"+textBox1.Text+"')";
            SqlDataAdapter SDA1 = new SqlDataAdapter(str, con);
            SDA1.SelectCommand.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("new employee created");
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
