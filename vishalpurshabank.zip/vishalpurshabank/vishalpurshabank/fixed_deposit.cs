﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace vishalpurshabank
{
   
    public partial class fixed_deposit : UserControl
    {
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");
        public fixed_deposit()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            String query = "insert into balanceaccount(fixed_deposit,fixed_intrest,duration)values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "')";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            sda.SelectCommand.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("inserted successfully!!");

        }
    }
}
