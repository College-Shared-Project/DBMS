﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace vishalpurshabank
{
    public partial class Addintrests : UserControl
    {
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");

        public Addintrests()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


        }
        public void grid()
        {
            con.Open();
            String view_query = "select Accountno,save_balance,fixed_deposit from balanceaccount1";
            SqlDataAdapter v_sda = new SqlDataAdapter(view_query, con);
            v_sda.SelectCommand.ExecuteNonQuery();
            DataTable dt = new DataTable();
            v_sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
        private void Addintrests_Load(object sender, EventArgs e)
        {
            grid();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            con.Open();
            SqlCommand cmd1 = new SqlCommand("intrest4", con);
            cmd1.CommandType = CommandType.StoredProcedure;
            cmd1.ExecuteNonQuery();

            con.Close();
            grid();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
