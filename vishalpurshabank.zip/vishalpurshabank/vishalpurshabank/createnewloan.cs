﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vishalpurshabank
{
    public partial class createnewloan : Form
    {
        public createnewloan()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loan lo = new loan();
            lo.Show();
            this.Hide();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
