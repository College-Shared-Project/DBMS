﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace vishalpurshabank
{
    public partial class adminlogin : Form
    {
        String sSelectedFile;
        String sSelectedFolder;

        public adminlogin()
        {
                InitializeComponent();
        
        }

        private void button2_Click(object sender, EventArgs e)
        {
           adminloandetails1.BringToFront();
        }
       
        private void button10_Click(object sender, EventArgs e)
        {


            updatemenu1.BringToFront();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            employeecreate1.BringToFront();
          
        }

        private void button7_Click(object sender, EventArgs e)
        {
            seachbyaccount11.BringToFront();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            deleteEmployee1.BringToFront();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            viewemployeinfo1.BringToFront();
        }

        private void first1_Load(object sender, EventArgs e)
        {

        }

        private void viewemployeinfo1_Load(object sender, EventArgs e)
        {

           
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void deleteaccountuser1_Load(object sender, EventArgs e)
        {

        }

        private void b1_Click(object sender, EventArgs e)
        {
            viewtransactionadmin1.BringToFront();
        }

        private void adminlogin_Load(object sender, EventArgs e)
        {

        }

        private void adminloandetails1_Load(object sender, EventArgs e)
        {

        }

        private void viewtransactionadmin1_Load(object sender, EventArgs e)
        {

        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            addintrests1.BringToFront();
        }

        private void addintrests1_Load(object sender, EventArgs e)
        {

        }

        private void employeecreate1_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
    }
}
