﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
    namespace vishalpurshabank
{
    public partial class viewtransactionadmin : UserControl
    {
        public viewtransactionadmin()
        {
            InitializeComponent();
        }

        private void viewtransactionadmin_Load(object sender, EventArgs e)
        {
            
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");
            if (comboBox1.Text == "Account info")
            {
                con.Open();
                String view_query = "select * from admin_log where logtext='New Account created --' ";

                SqlDataAdapter v_sda = new SqlDataAdapter(view_query, con);
                v_sda.SelectCommand.ExecuteNonQuery();
                DataTable dt = new DataTable();
                v_sda.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
                this.Refresh();
            }
            else if (comboBox1.Text == "Deposit info")
            {
                con.Open();
                String view_query1 = "select * from admin_log where logtext='deposit'";

                SqlDataAdapter v_sda1 = new SqlDataAdapter(view_query1, con);
                v_sda1.SelectCommand.ExecuteNonQuery();
                DataTable dt = new DataTable();
                v_sda1.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
                this.Refresh();
            }
            else if(comboBox1.Text== "Withdraw info")
            {
                con.Open();
                String view_query2 = "select * from admin_log where logtext='Withdarw'";

                SqlDataAdapter v_sda2 = new SqlDataAdapter(view_query2, con);
                v_sda2.SelectCommand.ExecuteNonQuery();
                DataTable dt = new DataTable();
                v_sda2.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
                this.Refresh();
            }
            else if (comboBox1.Text == "Loan")
            {
                con.Open();
                String view_query2 = "select * from admin_log where logtext='New loan created --'";

                SqlDataAdapter v_sda2 = new SqlDataAdapter(view_query2, con);
                v_sda2.SelectCommand.ExecuteNonQuery();
                DataTable dt = new DataTable();
                v_sda2.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
                this.Refresh();
            }
            else
            {
                con.Open();
                String view_query2 = "select * from admin_log ";

                SqlDataAdapter v_sda2 = new SqlDataAdapter(view_query2, con);
                v_sda2.SelectCommand.ExecuteNonQuery();
                DataTable dt = new DataTable();
                v_sda2.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
                this.Refresh();
            }
        }
    }
}
