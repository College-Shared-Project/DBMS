﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace vishalpurshabank
{
    public partial class withdramenu : UserControl
    {

        string label;
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");


        public withdramenu()
        {
            InitializeComponent();
        }

        private void withdramenu_Load(object sender, EventArgs e)
        {
            con.Open();
            int i = 0;
            String str = "select path from image1 where name='withdraw' ";
            SqlCommand cmd1 = new SqlCommand(str, con);
            SqlDataReader dr = cmd1.ExecuteReader();
            dr.Read();
            label = dr[0].ToString();
            con.Close();
            pictureBox1.ImageLocation = string.Format(label);

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
