﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace vishalpurshabank
{
    public partial class seachbyaccount1 : UserControl
    {
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=bankdata;Integrated Security=True");
        String str;
        SqlCommand com;
        public seachbyaccount1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();

            str = "select Accountno,pincode,customername,dateofbirth,sex from account1 where Accountno='"+textBox1.Text+"'";
            SqlDataAdapter adpt = new SqlDataAdapter(str, con);
            DataSet login = new DataSet();
            adpt.Fill(login);
            foreach (DataRow dr in login.Tables[0].Rows)
            {
                label6.Text += login.Tables[0].Rows[0]["Accountno"].ToString();
                label7.Text += login.Tables[0].Rows[0]["pincode"].ToString();
                label8.Text += login.Tables[0].Rows[0]["customername"].ToString();
                label9.Text += login.Tables[0].Rows[0]["dateofbirth"].ToString();
                label10.Text += login.Tables[0].Rows[0]["sex"].ToString();
            }
            con.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            label6.Text = null;
            label7.Text = null;
            label8.Text = null;
            label9.Text = null;
            label10.Text = null;

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
