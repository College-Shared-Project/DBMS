﻿select * from account;
select * from balanceaccount;

select a.Accountno,a.pincode,a.customername,a.Fathername,a.dateofbirth,a.sex,a.cellnumber,a.country,a.cityname,a.address,a.date,b.save_balance,b.fixed_deposit,b.duration from account a,balanceaccount b where a.Accountno=b.Accountno;
n