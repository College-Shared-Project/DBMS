﻿delete from account where pincode=123;
select * from account;